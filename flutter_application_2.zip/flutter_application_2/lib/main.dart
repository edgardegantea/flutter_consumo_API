import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'models/cancion.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late Future<List<Cancion>> _listadoCanciones;

  Future<List<Cancion>> _getCanciones() async {
    final response = await http.get((Uri.parse("http://rodrigo758.pythonanywhere.com/cancion")));

    List<Cancion> canciones = [];

    if (response.statusCode == 200) {
      String body = utf8.decode(response.bodyBytes);

      final jsonData = jsonDecode(body);

      for (var item in jsonData["data"]) {
        canciones.add(Cancion(item["nombre"], item['pista'], item['duracion']));
      }

      return canciones;
    } else {
      throw Exception("Falló la conexión");
    }
  }

  @override
  void initState() {
    super.initState();
    _listadoCanciones = _getCanciones();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Consumo de api',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Consumo de API'),
        ),
        body: FutureBuilder<dynamic>(
          future: _listadoCanciones,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return GridView.count(
                crossAxisCount: 2,
                children: _listCancion(snapshot.data),
              );
            } else if (snapshot.hasError) {
              print(snapshot.error);
              return Text("Error");
            }

            return Center(
              child: CircularProgressIndicator(),
            );
          },
        ),
      ),
    );
  }

  List<Widget> _listCancion(List<Cancion> data) {
    List<Widget> canciones = [];

    for (var cancion in data) {
      canciones.add(Card(child: Column(
        children: [
          Expanded(child: Text(cancion.nombre)),
          Expanded(child: Text(cancion.pista)),
          Expanded(child: Text(cancion.duracion)),
        ],
      )));
    }

    return canciones;
  }
}