class Cancion {
  String nombre="";
  String pista="";
  String duracion="";


  Cancion(nombre, pista, duracion) {
    this.nombre = nombre;
    this.pista = pista;
    this.duracion = duracion;
  }
}